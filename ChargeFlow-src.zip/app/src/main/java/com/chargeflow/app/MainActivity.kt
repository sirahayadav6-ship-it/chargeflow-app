package com.chargeflow.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = dp(20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(label("⚡ ChargeFlow", 28f, Color.WHITE))
        root.addView(label("Charger lagao → lock screen pe animation, watt aur full hone ka time.", 14f, Color.LTGRAY))
        status = label("", 15f, Color.parseColor("#00E5A0")).apply { setPadding(0, pad, 0, pad) }
        root.addView(status)
        root.addView(button("1. Notification permission") { askNotif() })
        root.addView(button("2. Display over other apps (ON karo)") { overlay() })
        root.addView(button("3. Battery optimization OFF") { battery() })
        root.addView(button("4. Service start karo") { startSvc(); refresh() })
        root.addView(button("▶ Test animation") {
            startActivity(Intent(this, ChargingActivity::class.java).putExtra("demo", true))
        })
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0B0F14"))
            isFillViewport = true
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        startSvc()
        refresh()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        refresh()
    }

    private fun refresh() {
        val notif = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val over = Settings.canDrawOverlays(this)
        val bat = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        status.text = "${tick(notif)} Notification\n${tick(over)} Display over other apps\n${tick(bat)} Battery optimization off"
    }

    private fun tick(b: Boolean) = if (b) "✅" else "❌"

    private fun startSvc() {
        try { startForegroundService(Intent(this, ChargingService::class.java)) } catch (_: Exception) {}
    }

    private fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    private fun overlay() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun battery() {
        startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
    }

    private fun label(t: String, size: Float, color: Int) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
