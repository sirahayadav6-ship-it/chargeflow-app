package com.chargeflow.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.PI
import kotlin.math.sin

/** Charging animation: pulse rings + bharta hua battery + bijli ka nishan. */
class ChargeView(context: Context) : View(context) {

    var percent = 0f
    var color = 0xFF00E5A0.toInt()
    var animating = true

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private val wave = Path()
    private val bolt = Path()
    private val body = RectF()

    override fun onDraw(canvas: Canvas) {
        val t = System.nanoTime() / 1e9
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val bw = minOf(w * 0.34f, h * 0.30f)
        val bh = bw * 1.75f

        // pulse rings
        if (animating) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 3f
            for (i in 0 until 3) {
                val ph = ((t * 0.4 + i / 3.0) % 1.0).toFloat()
                p.color = color
                p.alpha = ((1f - ph) * 90).toInt()
                canvas.drawCircle(cx, cy, bw * 0.9f + ph * bw * 1.1f, p)
            }
        }

        val left = cx - bw / 2
        val right = cx + bw / 2
        val top = cy - bh / 2
        val bottom = cy + bh / 2
        val r = bw * 0.16f
        body.set(left, top, right, bottom)

        // battery cap
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        p.alpha = 120
        canvas.drawRoundRect(cx - bw * 0.18f, top - bw * 0.1f, cx + bw * 0.18f, top + bw * 0.03f, 6f, 6f, p)

        // liquid fill
        clip.reset()
        clip.addRoundRect(body, r, r, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(clip)
        val fillTop = bottom - bh * (percent.coerceIn(0f, 100f) / 100f)
        val amp = if (animating) bw * 0.04f else 0f
        wave.reset()
        wave.moveTo(left, bottom)
        wave.lineTo(left, fillTop)
        var x = left
        while (x <= right) {
            val y = fillTop + sin((x - left) / bw * 2 * PI * 1.5 + t * 3).toFloat() * amp
            wave.lineTo(x, y)
            x += 4f
        }
        wave.lineTo(right, bottom)
        wave.close()
        p.style = Paint.Style.FILL
        p.color = color
        p.alpha = 230
        canvas.drawPath(wave, p)
        canvas.restore()

        // outline
        p.style = Paint.Style.STROKE
        p.strokeWidth = bw * 0.035f
        p.color = Color.WHITE
        p.alpha = 200
        canvas.drawRoundRect(body, r, r, p)

        // bolt
        bolt.reset()
        val k = bw * 0.85f
        val pts = floatArrayOf(
            0.12f, -0.5f, -0.28f, 0.08f, -0.02f, 0.08f,
            -0.12f, 0.5f, 0.28f, -0.1f, 0.02f, -0.1f
        )
        for (i in pts.indices step 2) {
            val px = cx + pts[i] * k
            val py = cy + pts[i + 1] * k
            if (i == 0) bolt.moveTo(px, py) else bolt.lineTo(px, py)
        }
        bolt.close()
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        p.alpha = (200 + 55 * sin(t * 4)).toInt().coerceIn(0, 255)
        canvas.drawPath(bolt, p)

        postInvalidateOnAnimation()
    }
}
